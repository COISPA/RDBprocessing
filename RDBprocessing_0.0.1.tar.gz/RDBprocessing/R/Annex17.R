#' Annex 1.7
#'
#' @name Annex17
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords Annex17
"Annex17"
