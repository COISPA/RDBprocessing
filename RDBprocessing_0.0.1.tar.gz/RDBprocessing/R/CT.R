#' CT communication table GFCM-MEDBS-FDI
#'
#' @name CT
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM_fleet_segments
"CT"
