#' RBD CE example (https://www.ices.dk/data/Documents/RDB/RDB%20Exchange%20Format.pdf)
#'
#' @name ce_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords RDB, CE, effort_data
"ce_example"
