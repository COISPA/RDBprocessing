#' RCG CL example
#'
#' @name data_exampleCL
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords RCG, CL, landing data
"data_exampleCL"
