

#' RCG CS example
#'
#' @name data_ex
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords RCG
"data_ex"




#' Annex 1.7
#'
#' @name Annex17
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords Annex17
"Annex17"
