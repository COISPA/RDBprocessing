#' CATCH_FDIex : example of Catch table FDI
#'
#' @name CATCH_FDIex
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI Catch
"CATCH_FDIex"
