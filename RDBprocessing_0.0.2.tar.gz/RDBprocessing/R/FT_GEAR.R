#' communication table fishing technique- gear based on Italian FDI data
#'
#' @name FT_GEAR
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords fishing technique gear FDI
"FT_GEAR"
