#' communicationTable_for_fishery
#'
#' @name fishery
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords communicationTable_for_fishery
"fishery"
