#' Mesh size range codification MED &  BS data call
#'
#' @name msr
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords mesh_size_code
"msr"
